import BirthdayList from "./components/BirthdayList";
function App() {
  return (
    <>
      <BirthdayList />
    </>
  );
}

export default App;
